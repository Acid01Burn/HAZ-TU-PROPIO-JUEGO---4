var cabaña_img,background_img,personaje_1,personaje_2,personaje_3,personaje_4;
var Button,Button_2;
var button_2,button_3,button_4,button_5;
var dialogo_narrador1,dialogo_narrador2,dialogo_narrador3,dialogo_narrador4,dialogo_narrador5,dialogo_narrador6,dialogo_narrador7,dialogo_narrador8,dialogo_narrador9,dialogo_narrador10,dialogo_narrador11,dialogo_narrador12,dialogo_narrador13,dialogo_narrador14,dialogo_narrador15,dialogo_narrador16,dialogo_narrador17;
var dialogo_jake1,dialogo_jake2,dialogo_jake3,dialogo_jake4;
var dialogo_esteicie1,dialogo_esteicie2;
var dialogo_jimena1;
 var dialogo_samuel1,dialogo_samuel2;
var bandera = 0;
var sprite_1;
var barra_1;

function preload(){
cabaña_img = loadImage("./imagenes/Cabaña.jpg");
background_img = loadImage("./imagenes/background.jpg");
interior_img = loadImage("./imagenes/interior de la cabaña.jpg");
cuarto_img = loadImage("./imagenes/cuarto desordenado.jpg");

personaje_1 = loadImage("./imagenes/Jake.jpg");
personaje_2 = loadImage("./imagenes/Esteicie.jpg");
personaje_3 = loadImage("./imagenes/Jimena.png");
personaje_4 = loadImage("./imagenes/Samuel.png");

dialogo_narrador1 = loadImage("./narrador/Narrador (1).png");
dialogo_narrador2 = loadImage("./narrador/Narrador (2).png");
dialogo_narrador3 = loadImage("./narrador/Narrador (3).png");
dialogo_narrador4 = loadImage("./narrador/Narrador (4).png");
dialogo_narrador5 = loadImage("./narrador/Narrador (5).png");
dialogo_narrador6 = loadImage("./narrador/Narrador (6).png");
dialogo_narrador7 = loadImage("./narrador/Narrador (7).png");
dialogo_narrador8 = loadImage("./narrador/Narrador (8).png");
dialogo_narrador9 = loadImage("./narrador/Narrador (9).png");
dialogo_narrador10 = loadImage("./narrador/Narrador (10).png");
dialogo_narrador11 = loadImage("./narrador/Narrador (11).png");
dialogo_narrador12 = loadImage("./narrador/Narrador (12).png");
dialogo_narrador13 = loadImage("./narrador/Narrador (13).png");
dialogo_narrador14 = loadImage("./narrador/Narrador (14).png");
dialogo_narrador15 = loadImage("./narrador/Narrador (15).png");
dialogo_narrador16 = loadImage("./narrador/Narrador (16).png");
dialogo_narrador17 = loadImage("./narrador/Narrador (17).png");

dialogo_jake1 = loadImage("./persoanjes/Jake (1).png");
dialogo_jake2 = loadImage("./persoanjes/Jake (2).png");
dialogo_jake3 = loadImage("./persoanjes/Jake (3).png");
dialogo_jake4 = loadImage("./persoanjes/Jake (4).png");

dialogo_esteicie1 = loadImage("./persoanjes/Esteicie (1).png");
dialogo_esteicie2 = loadImage("./persoanjes/Esteicie (2).png");

dialogo_jimena1 = loadImage("./persoanjes/Jimena (1).png");

dialogo_samuel1 = loadImage("./persoanjes/Samuel (1).png");
dialogo_samuel2 = loadImage("./persoanjes/Samuel (2).png");
}

function setup(){
  createCanvas(900,700);

  Button = createButton('continuar');
  Button.position(800, 660);
  Button.mousePressed(Escenarios);
  
  sprite_1 = createSprite(width,height-50);
  sprite_1.addImage("escenario_1",background_img);
  sprite_1.addImage("escenario_2",interior_img);
  sprite_1.addImage("cuarto",cuarto_img);
  sprite_1.visible = false;

  barra_1 = createSprite(width-50,height);
  barra_1.addImage("narrador",dialogo_narrador1);
  barra_1.addImage("narrador_2",dialogo_narrador2);
  barra_1.addImage("narrador_3",dialogo_narrador2);
  barra_1.addImage("narrador_4",dialogo_narrador2);
  barra_1.addImage("narrador_5",dialogo_narrador2);
  barra_1.addImage("narrador_6",dialogo_narrador2);
  barra_1.addImage("narrador_7",dialogo_narrador2);
  barra_1.addImage("narrador_8",dialogo_narrador2);
  barra_1.addImage("narrador_9",dialogo_narrador2);
  barra_1.addImage("narrador_10",dialogo_narrador2);
  barra_1.addImage("narrador_11",dialogo_narrador2);
  barra_1.addImage("narrador_12",dialogo_narrador2);
  barra_1.addImage("narrador_13",dialogo_narrador2);
  barra_1.addImage("narrador_14",dialogo_narrador2);
  barra_1.addImage("narrador_15",dialogo_narrador2);
  barra_1.addImage("narrador_16",dialogo_narrador2);
  barra_1.addImage("narrador_17",dialogo_narrador2);
  barra_1.visible= false;
}

function draw(){
background(189);
image(cabaña_img,0,0,width,height);

fill("#F0F0F0");
textSize(20);
text(`Tu y tus amigos rentaron una cabaña en el bosque, donde van a tomarse un descanso 
despues de estar jugando fueron todos a sus habitaciones para dormir, pero tu despertaste 
por un ruido`,10,600);
//textAlign(CENTER, CENTER);
drawSprites();
}

function Escenarios() {
  console.log("hola");
  Button.hide();
 
  sprite_1.visible = true;
  sprite_1.changeImage("escenario_1");

  button_2 = createButton('Volver a dormir');
  button_2.position(width/2,height/2);
  button_2.mousePressed(opcion1);

  button_3 = createButton('Ir a investigar');
  button_3.position(width/2,height/2+30);

}

function opcion1(){
  button_2.hide();
  button_3.hide();
  
  sprite_1.visible = true;
  sprite_1.changeImage("escenario_2");

  barra_1.visible = true;
  barra_1.changeImage("narrador");
  barra_1.scale = 0.09;

  Button_2 = createButton('continuar');
  Button_2.position(800, 660);
  Button_2.mousePressed(() => {
    barra_1.hide();
    sprite_1.visible = true;
    sprite_1.changeImage("cuarto");
    barra_1.changeImage("narrador_2");
    barra_1.hide();
    barra_1.changeImage("narrador_3");
    barra_1.hide();
    barra_1.changeImage("narrador_4");
  });

 /* button_4 = createButton('Decirle a tus amigos');
  button_4.position(width/2,height/2);
  button_4 = mousePressed(chat);

  button_5 = createButton('No decirles');
  button_5.position(width/2,height/2+30);*/
}

function chat(){
  
}
